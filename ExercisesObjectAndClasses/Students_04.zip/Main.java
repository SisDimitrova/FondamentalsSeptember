package Students_04;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int countStudents = Integer.parseInt(scanner.nextLine());
        List<Students> studentsList = new ArrayList<>();

        for (int i = 1; i <= countStudents ; i++) {
            String[] studentData = scanner.nextLine().split(" ");
            String firstName = studentData[0];
            String secondName = studentData[1];
            double grade = Double.parseDouble(studentData[2]);

            Students students = new Students(firstName, secondName, grade);
            studentsList.add(students);
        }
        Collections.sort(studentsList, Comparator.comparingDouble(Students::getGrade).reversed());

        for (Students student : studentsList) {
            System.out.printf("%s %s: %.2f%n", student.getFirstName(), student.getSecondName(), student.getGrade());
        }
    }
}
